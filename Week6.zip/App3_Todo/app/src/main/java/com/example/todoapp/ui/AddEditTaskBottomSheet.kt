package com.example.todoapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import com.example.todoapp.databinding.BottomSheetAddEditTaskBinding
import com.example.todoapp.model.Priority
import com.example.todoapp.model.Task
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

/**
 * BottomSheetDialogFragment for creating or editing a task.
 *
 * Flutter equivalent: showModalBottomSheet() with a StatefulWidget form,
 * where local form state lives in a stateful widget (or a local Provider scope).
 *
 * Here we keep the form state directly in the Fragment view — no ViewModel
 * needed for ephemeral UI-only state (same principle as Flutter's local state).
 * The result is passed up via a callback lambda, which the ViewModel then
 * processes to update the shared StateFlow.
 */
class AddEditTaskBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetAddEditTaskBinding? = null
    private val binding get() = _binding!!

    private var existingTask: Task? = null
    private var onSave: ((String, String, Priority) -> Unit)? = null

    companion object {
        fun newInstance(
            task: Task?,
            onSave: (title: String, description: String, priority: Priority) -> Unit
        ): AddEditTaskBottomSheet {
            return AddEditTaskBottomSheet().apply {
                this.existingTask = task
                this.onSave = onSave
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetAddEditTaskBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Show keyboard automatically
        dialog?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)

        // Pre-fill fields when editing
        existingTask?.let { task ->
            binding.etTitle.setText(task.title)
            binding.etDescription.setText(task.description)
            binding.tvSheetTitle.text = "Edit Task"
            when (task.priority) {
                Priority.LOW    -> binding.rgPriority.check(binding.rbLow.id)
                Priority.MEDIUM -> binding.rgPriority.check(binding.rbMedium.id)
                Priority.HIGH   -> binding.rgPriority.check(binding.rbHigh.id)
            }
        } ?: run {
            binding.rgPriority.check(binding.rbMedium.id) // default
        }

        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString().trim()
            if (title.isEmpty()) {
                binding.etTitle.error = "Title is required"
                return@setOnClickListener
            }
            val description = binding.etDescription.text.toString().trim()
            val priority = when (binding.rgPriority.checkedRadioButtonId) {
                binding.rbLow.id  -> Priority.LOW
                binding.rbHigh.id -> Priority.HIGH
                else              -> Priority.MEDIUM
            }
            onSave?.invoke(title, description, priority)
            dismiss()
        }

        binding.btnCancel.setOnClickListener { dismiss() }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
