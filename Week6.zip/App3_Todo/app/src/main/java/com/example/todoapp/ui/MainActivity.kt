package com.example.todoapp.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import com.example.todoapp.adapter.TaskAdapter
import com.example.todoapp.databinding.ActivityMainBinding
import com.example.todoapp.model.Task
import com.example.todoapp.model.TaskFilter
import com.example.todoapp.viewmodel.TaskViewModel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

/**
 * MainActivity — the "widget tree root" of our app.
 *
 * Flutter Provider equivalent:
 *   In Flutter: ChangeNotifierProvider wraps the widget tree, and
 *   Consumer<TaskViewModel> rebuilds when notifyListeners() is called.
 *
 *   Here: lifecycleScope.launch { viewModel.filteredTasks.collect { list ->
 *       adapter.submitList(list)  // re-render only changed items
 *   }}
 *
 *   The viewModels() delegate is the equivalent of
 *   Provider.of<TaskViewModel>(context) — it survives configuration changes.
 */
class MainActivity : AppCompatActivity() {

    // ViewBinding — no annotation processor; AGP generates the class at compile time
    private lateinit var binding: ActivityMainBinding

    // viewModels() = equivalent of Flutter's context.read<TaskViewModel>()
    // The ViewModel survives rotation (like Provider's scoped lifetime)
    private val viewModel: TaskViewModel by viewModels()

    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupFilterTabs()
        setupSearch()
        setupFab()
        observeState()          // ← this is where StateFlow replaces Provider/Consumer
    }

    // ── RecyclerView ─────────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = TaskAdapter(
            onToggle = { task -> viewModel.toggleComplete(task.id) },
            onEdit   = { task -> showTaskDialog(task) },
            onDelete = { task ->
                viewModel.deleteTask(task.id)
                Snackbar.make(binding.root, "Task deleted", Snackbar.LENGTH_LONG)
                    .setAction("Undo") {
                        viewModel.addTask(task.title, task.description, task.priority)
                    }
                    .show()
            }
        )
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        binding.rvTasks.adapter = adapter

        // Swipe-to-delete gesture
        val swipeCallback = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder,
                                target: RecyclerView.ViewHolder) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val pos  = viewHolder.adapterPosition
                val task = adapter.currentList[pos]
                viewModel.deleteTask(task.id)
                Snackbar.make(binding.root, "\"${task.title}\" deleted", Snackbar.LENGTH_LONG)
                    .setAction("Undo") {
                        viewModel.addTask(task.title, task.description, task.priority)
                    }.show()
            }
        }
        ItemTouchHelper(swipeCallback).attachToRecyclerView(binding.rvTasks)
    }

    // ── Filter tabs ──────────────────────────────────────────────────────────

    private fun setupFilterTabs() {
        binding.chipAll.setOnClickListener       { viewModel.setFilter(TaskFilter.ALL) }
        binding.chipActive.setOnClickListener    { viewModel.setFilter(TaskFilter.ACTIVE) }
        binding.chipCompleted.setOnClickListener { viewModel.setFilter(TaskFilter.COMPLETED) }
    }

    // ── Search ───────────────────────────────────────────────────────────────

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int)     = Unit
            override fun afterTextChanged(s: Editable?) {
                viewModel.setSearchQuery(s?.toString() ?: "")
            }
        })
    }

    // ── FAB ──────────────────────────────────────────────────────────────────

    private fun setupFab() {
        binding.fabAdd.setOnClickListener { showTaskDialog(null) }
        binding.btnClearDone.setOnClickListener {
            viewModel.clearCompleted()
            Snackbar.make(binding.root, "Completed tasks cleared", Snackbar.LENGTH_SHORT).show()
        }
    }

    // ── State observation (Flutter Consumer<T> equivalent) ───────────────────

    /**
     * observeState() collects from StateFlows and updates the UI reactively.
     *
     * Flutter equivalent:
     *   Consumer<TaskViewModel>(
     *     builder: (context, vm, child) => ListView.builder(...)
     *   )
     *
     * Each launch { flow.collect { } } block is like a separate Consumer
     * scoped to exactly the slice of state it needs.
     */
    private fun observeState() {

        // 1. Filtered task list → RecyclerView
        lifecycleScope.launch {
            viewModel.filteredTasks.collect { tasks ->
                adapter.submitList(tasks)
                binding.tvEmptyState.visibility = if (tasks.isEmpty()) View.VISIBLE else View.GONE
                binding.rvTasks.visibility      = if (tasks.isEmpty()) View.GONE    else View.VISIBLE
            }
        }

        // 2. Stats banner
        lifecycleScope.launch {
            viewModel.stats.collect { stats ->
                binding.tvStats.text = "${stats.total} tasks · ${stats.completed} done · ${stats.active} active"
                binding.progressTasks.max      = stats.total.coerceAtLeast(1)
                binding.progressTasks.progress = stats.completed
            }
        }

        // 3. Active filter → chip highlight
        lifecycleScope.launch {
            viewModel.filter.collect { filter ->
                binding.chipAll.isChecked       = filter == TaskFilter.ALL
                binding.chipActive.isChecked    = filter == TaskFilter.ACTIVE
                binding.chipCompleted.isChecked = filter == TaskFilter.COMPLETED
            }
        }
    }

    // ── Add / Edit dialog ────────────────────────────────────────────────────

    private fun showTaskDialog(existingTask: Task?) {
        AddEditTaskBottomSheet.newInstance(existingTask) { title, desc, priority ->
            if (existingTask == null) {
                viewModel.addTask(title, desc, priority)
            } else {
                viewModel.updateTask(existingTask.id, title, desc, priority)
            }
        }.show(supportFragmentManager, "AddEditTask")
    }
}
