package com.example.todoapp.adapter

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import com.example.todoapp.databinding.ItemTaskBinding
import com.example.todoapp.model.Task

/**
 * TaskAdapter uses ListAdapter (backed by DiffUtil) for efficient, animated
 * list updates — no manual notifyDataSetChanged() calls needed.
 *
 * This mirrors Flutter's AnimatedList or ListView.builder with keys:
 * only the changed items are re-drawn, not the entire list.
 */
class TaskAdapter(
    private val onToggle: (Task) -> Unit,
    private val onEdit:   (Task) -> Unit,
    private val onDelete: (Task) -> Unit
) : ListAdapter<Task, TaskAdapter.TaskViewHolder>(TaskDiffCallback()) {

    private var lastAnimatedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
        // Slide-in animation for new items (equivalent to Flutter's AnimatedOpacity / SlideTransition)
        if (position > lastAnimatedPosition) {
            val anim = AnimationUtils.loadAnimation(holder.itemView.context, R.anim.item_slide_in)
            holder.itemView.startAnimation(anim)
            lastAnimatedPosition = position
        }
    }

    inner class TaskViewHolder(private val binding: ItemTaskBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(task: Task) {
            binding.tvTitle.text       = task.title
            binding.tvDescription.text = task.description
            binding.tvPriority.text    = task.priority.label
            binding.cbComplete.isChecked = task.isCompleted

            // Strike-through completed tasks (like Flutter's TextDecoration.lineThrough)
            if (task.isCompleted) {
                binding.tvTitle.paintFlags = binding.tvTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                binding.tvTitle.alpha = 0.5f
                binding.tvDescription.alpha = 0.5f
            } else {
                binding.tvTitle.paintFlags = binding.tvTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                binding.tvTitle.alpha = 1f
                binding.tvDescription.alpha = 0.7f
            }

            // Priority badge color
            val priorityColor = ContextCompat.getColor(binding.root.context, task.priority.colorRes)
            binding.viewPriorityBar.setBackgroundColor(priorityColor)
            binding.tvPriority.setTextColor(priorityColor)

            // Description visibility
            binding.tvDescription.visibility =
                if (task.description.isBlank()) View.GONE else View.VISIBLE

            // Listeners
            binding.cbComplete.setOnClickListener { onToggle(task) }
            binding.btnEdit.setOnClickListener    { onEdit(task) }
            binding.btnDelete.setOnClickListener  { onDelete(task) }
            binding.root.setOnClickListener       { onEdit(task) }
        }
    }
}

class TaskDiffCallback : DiffUtil.ItemCallback<Task>() {
    override fun areItemsTheSame(old: Task, new: Task) = old.id == new.id
    override fun areContentsTheSame(old: Task, new: Task) = old == new
}
