package com.example.todoapp.viewmodel

import androidx.lifecycle.ViewModel
import com.example.todoapp.model.Priority
import com.example.todoapp.model.Task
import com.example.todoapp.model.TaskFilter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine

/**
 * TaskViewModel — Kotlin equivalent of Flutter's Provider + ChangeNotifier.
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  Flutter                        │  Kotlin (this file)                  │
 * ├─────────────────────────────────┼──────────────────────────────────────┤
 * │  ChangeNotifier                 │  ViewModel                           │
 * │  notifyListeners()              │  MutableStateFlow.value = newState   │
 * │  Provider.of<T>(context)        │  viewModels() delegate               │
 * │  Consumer<TaskProvider>         │  lifecycleScope { flow.collect {} }  │
 * │  context.read<T>().addTask()    │  viewModel.addTask()                 │
 * │  setState { }  (old approach)   │  _tasks.update { it + newTask }      │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * StateFlow is a hot flow — it always holds the latest value (like a
 * ChangeNotifier that always has a current state), and new collectors
 * immediately receive the latest emission.
 */
class TaskViewModel : ViewModel() {

    // ── Raw task list ────────────────────────────────────────────────────────
    // MutableStateFlow = mutable backing store (private to ViewModel)
    // StateFlow        = read-only public surface (exposed to UI)
    private val _tasks = MutableStateFlow<List<Task>>(emptyList())

    // ── Active filter ────────────────────────────────────────────────────────
    private val _filter = MutableStateFlow(TaskFilter.ALL)
    val filter: StateFlow<TaskFilter> = _filter.asStateFlow()

    // ── Search query ─────────────────────────────────────────────────────────
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    /**
     * filteredTasks combines _tasks + _filter + _searchQuery into a single
     * derived StateFlow — equivalent to a Flutter Provider that computes a
     * getter from multiple other Providers (or a Selector widget).
     *
     * combine() emits a new value whenever ANY of the three sources change,
     * so the UI always sees the correct filtered+searched list without
     * any manual coordination.
     */
    val filteredTasks: kotlinx.coroutines.flow.Flow<List<Task>> =
        combine(_tasks, _filter, _searchQuery) { tasks, filter, query ->
            tasks
                .filter { task ->
                    when (filter) {
                        TaskFilter.ALL       -> true
                        TaskFilter.ACTIVE    -> !task.isCompleted
                        TaskFilter.COMPLETED -> task.isCompleted
                    }
                }
                .filter { task ->
                    if (query.isBlank()) true
                    else task.title.contains(query, ignoreCase = true) ||
                         task.description.contains(query, ignoreCase = true)
                }
                .sortedWith(
                    compareBy<Task> { it.isCompleted }
                        .thenByDescending { it.priority.ordinal }
                        .thenByDescending { it.createdAt }
                )
        }

    // ── Stats derived from raw list ──────────────────────────────────────────
    val stats: kotlinx.coroutines.flow.Flow<TaskStats> = _tasks.let { tasksFlow ->
        kotlinx.coroutines.flow.map(tasksFlow) { tasks ->
            TaskStats(
                total     = tasks.size,
                completed = tasks.count { it.isCompleted },
                active    = tasks.count { !it.isCompleted }
            )
        }
    }

    // ── Seed some sample tasks on first run ──────────────────────────────────
    init {
        _tasks.value = listOf(
            Task(title = "Review project requirements", priority = Priority.HIGH,
                 description = "Go through the Week 6 task document thoroughly"),
            Task(title = "Set up ViewModel + StateFlow", priority = Priority.HIGH,
                 description = "Replace setState with proper state management"),
            Task(title = "Build RecyclerView with DiffUtil", priority = Priority.MEDIUM,
                 description = "Efficient list rendering with animations"),
            Task(title = "Add task filtering", priority = Priority.MEDIUM,
                 description = "All / Active / Completed tabs"),
            Task(title = "Write README.md", priority = Priority.LOW,
                 description = "Document setup steps and architecture decisions",
                 isCompleted = true)
        )
    }

    // ── Public API (mirrors Flutter ChangeNotifier methods) ──────────────────

    /** Add a new task — equivalent to TaskProvider.addTask() + notifyListeners() */
    fun addTask(title: String, description: String, priority: Priority) {
        if (title.isBlank()) return
        val newTask = Task(title = title.trim(), description = description.trim(), priority = priority)
        _tasks.value = _tasks.value + newTask
    }

    /** Toggle completion — creates an updated copy (immutable pattern) */
    fun toggleComplete(taskId: String) {
        _tasks.value = _tasks.value.map { task ->
            if (task.id == taskId) task.copy(isCompleted = !task.isCompleted) else task
        }
    }

    /** Update title, description, and priority of an existing task */
    fun updateTask(taskId: String, title: String, description: String, priority: Priority) {
        if (title.isBlank()) return
        _tasks.value = _tasks.value.map { task ->
            if (task.id == taskId)
                task.copy(title = title.trim(), description = description.trim(), priority = priority)
            else task
        }
    }

    /** Delete a task by ID */
    fun deleteTask(taskId: String) {
        _tasks.value = _tasks.value.filter { it.id != taskId }
    }

    /** Clear all completed tasks at once */
    fun clearCompleted() {
        _tasks.value = _tasks.value.filter { !it.isCompleted }
    }

    /** Change active filter tab */
    fun setFilter(filter: TaskFilter) {
        _filter.value = filter
    }

    /** Update live search query */
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }
}

data class TaskStats(val total: Int, val completed: Int, val active: Int)
