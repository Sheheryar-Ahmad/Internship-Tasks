package com.example.todoapp.model

import java.util.UUID

/**
 * Immutable task model.
 *
 * Flutter Provider equivalent:
 *   In Flutter you would mutate a ChangeNotifier field and call notifyListeners().
 *   Here we use immutable data classes: every "mutation" creates a new copy
 *   via Kotlin's .copy(), and the ViewModel emits the new list into StateFlow.
 *   Collectors (Activities/Adapters) re-render automatically — exactly like
 *   Consumer<TaskProvider> rebuilding its widget subtree.
 */
data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val priority: Priority = Priority.MEDIUM,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class Priority(val label: String, val colorRes: Int) {
    LOW("Low", android.R.color.holo_green_dark),
    MEDIUM("Medium", android.R.color.holo_orange_dark),
    HIGH("High", android.R.color.holo_red_dark)
}
