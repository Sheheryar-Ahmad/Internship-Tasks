# Week 6 – Task Manager App (Kotlin)
### State Management with ViewModel + StateFlow (Flutter Provider Equivalent)

---

## 📱 Overview

A fully functional To-Do / Task Management Android app built in **Kotlin**, demonstrating
state management using **ViewModel + StateFlow** — the direct Kotlin equivalent of Flutter's
`Provider` package.

---

## 🗂️ Project Structure

```
app/src/main/java/com/example/todoapp/
├── model/
│   ├── Task.kt           # Immutable data class (like a Flutter @immutable model)
│   └── TaskFilter.kt     # Enum for filter tabs
├── viewmodel/
│   └── TaskViewModel.kt  # State container — replaces Flutter's ChangeNotifier Provider
├── adapter/
│   └── TaskAdapter.kt    # RecyclerView adapter with DiffUtil (like Flutter's ListView.builder)
└── ui/
    ├── MainActivity.kt              # Root UI — collects StateFlow (like Flutter's Consumer<T>)
    └── AddEditTaskBottomSheet.kt    # Modal form (like Flutter's showModalBottomSheet)
```

---

## 🔁 Flutter Provider → Kotlin ViewModel Mapping

| Flutter Concept | Kotlin Equivalent | File |
|---|---|---|
| `ChangeNotifier` class | `ViewModel` class | `TaskViewModel.kt` |
| `notifyListeners()` | `_stateFlow.value = newValue` | `TaskViewModel.kt` |
| `ChangeNotifierProvider(...)` | `by viewModels()` delegate | `MainActivity.kt` |
| `Provider.of<T>(context)` | `viewModel.someFlow` | `MainActivity.kt` |
| `Consumer<TaskViewModel>` | `lifecycleScope.launch { flow.collect { } }` | `MainActivity.kt` |
| `context.read<T>().addTask()` | `viewModel.addTask(...)` | `MainActivity.kt` |
| `setState { }` (old approach) | `_tasks.value = _tasks.value + newTask` | `TaskViewModel.kt` |
| Selector (derived state) | `combine(flow1, flow2) { ... }` | `TaskViewModel.kt` |
| `showModalBottomSheet()` | `BottomSheetDialogFragment.show()` | `AddEditTaskBottomSheet.kt` |
| `AnimatedList` | `ListAdapter` + DiffUtil | `TaskAdapter.kt` |
| `SlideTransition` / `FadeIn` | `R.anim.item_slide_in` animation | `anim/item_slide_in.xml` |

---

## ✨ Features

- ✅ **Add / Edit / Delete** tasks
- ✅ **Complete / Uncomplete** tasks with checkbox
- ✅ **Priority levels** — Low 🟢 / Medium 🟠 / High 🔴
- ✅ **Filter tabs** — All / Active / Done
- ✅ **Live search** — filters as you type
- ✅ **Progress bar** — shows completion percentage
- ✅ **Swipe to delete** with Undo snackbar
- ✅ **Slide-in animations** for new items
- ✅ **Strike-through** text for completed tasks
- ✅ **Stats banner** — total / active / completed count

---

## ⚙️ No KAPT — Why and How

The app deliberately avoids `kapt` (Kotlin Annotation Processing Tool):

| Feature | Solution used | Why no kapt |
|---|---|---|
| View binding | `buildFeatures { viewBinding true }` | AGP generates binding classes natively |
| State management | `StateFlow` + `ViewModel` | Pure Kotlin, no annotation processing |
| Dependency injection | None needed — simple ViewModel factory | State scoped to ViewModel directly |
| Database | **None** — in-memory `StateFlow<List<Task>>` | Task spec says in-memory state management |

> **If you add Room later**, replace `kapt` with `ksp` (Kotlin Symbol Processing):
> ```gradle
> id 'com.google.devtools.ksp' version '1.9.22-1.0.17'
> // then use ksp(...) instead of kapt(...) in dependencies
> ```

---

## 🚀 Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34
- A device or emulator running API 24+

### Steps

1. **Clone / open the project** in Android Studio
2. Let Gradle sync complete (it downloads all dependencies from Maven)
3. **Run** on an emulator or physical device (▶ button)

No Firebase, no API keys, no google-services.json needed — the app is self-contained.

---

## 🏗️ State Management Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     MainActivity (UI)                        │
│                                                              │
│  lifecycleScope.launch {                                     │
│    viewModel.filteredTasks.collect { tasks ->                │
│      adapter.submitList(tasks)  ← only changed items re-draw │
│    }                                                         │
│  }                                                           │
└──────────────────────┬──────────────────────────────────────┘
                       │  reads flows / calls methods
┌──────────────────────▼──────────────────────────────────────┐
│                   TaskViewModel                              │
│                                                              │
│  _tasks   : MutableStateFlow<List<Task>>                     │
│  _filter  : MutableStateFlow<TaskFilter>                     │
│  _search  : MutableStateFlow<String>                         │
│                                                              │
│  filteredTasks = combine(_tasks, _filter, _search) { ... }   │
│  stats         = _tasks.map { ... }                          │
│                                                              │
│  addTask() / toggleComplete() / deleteTask() / updateTask()  │
└─────────────────────────────────────────────────────────────┘
```

StateFlow is **hot** — it always holds the latest value and new collectors
immediately receive it. This mirrors how a `ChangeNotifier` always has
a current state that any new `Consumer` will immediately read.

---

## 📦 Dependencies (all from Maven, no kapt)

```gradle
implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0'
implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.7.0'
implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
implementation 'androidx.recyclerview:recyclerview:1.3.2'
implementation 'com.google.android.material:material:1.11.0'
```
